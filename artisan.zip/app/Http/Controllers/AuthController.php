<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class AuthController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register', 'forget' , 'reset']]);
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required',
            'goldar' => 'required'

        ]);

        if ($validator->fails()) {
            return response()->json([

                'response' => Response::HTTP_INTERNAL_SERVER_ERROR,
                'success' => false,
                'message' => $validator->errors(),
                'data' => []

            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }else{
            $user = new User;
            $user->name  = $request->name;
            $user->email  = $request->email;
            $user->goldar  = $request->goldar;
            $user->password  = Hash::make($request->password);
            $user->remember_token  = Str::random(60);
            $respons = $user->save();
    
            return response()->json([

                'response' => Response::HTTP_OK,
                'success' => true,
                'message' => 'Register successfully.',
                'data' => $respons

            ], Response::HTTP_OK);
        }
    }

    public function login()
    {
        $credentials = request(['email', 'password']);

        if (! $token = auth()->attempt($credentials)) {
            return response()->json([
                'response' => Response::HTTP_UNAUTHORIZED,
                'success' => false,
                'message' => 'Unauthorized',
                'data' => [],
            ], Response::HTTP_UNAUTHORIZED);
        }

        return $this->respondWithToken($token);
    }

    public function forget(Request $request ){
        $cek = User::where('email', $request->email)->first();
        if($cek == null){
            return response()->json([
                'response' => Response::HTTP_NOT_ACCEPTABLE,
                'success' => false,
                'message' => 'email is not registered',
                'data' => [],
            ], Response::HTTP_NOT_ACCEPTABLE);
        }else{
            $token = Str::random(32);
            DB::table('password_resets')->insert([
                'email' => $request->email, 
                'token' => $token, 
            ]); 
            // Mail::send('email.forgetPassword', ['token' => $token], function($message) use($request){
            //     $message->to($request->email);
            //     $message->subject('Reset Password');
            // });
            return response()->json([
                'response' => Response::HTTP_OK,
                'success' => true,
                'message' => 'email sent successfully',
                'data' => [],
            ], Response::HTTP_OK);
        }
    }

    public function reset($token, Request $request ){
        $updatePassword = DB::table('password_resets')->where([
            'email' => $request->email, 
            'token' => $token
        ])->first();
  
        if(!$updatePassword){
            return response()->json([
                'response' => Response::HTTP_FORBIDDEN,
                'success' => false,
                'message' => 'Invalid Token',
                'data' => [],
            ], Response::HTTP_FORBIDDEN);
        }
        User::where('email', $request->email)->update(['password' => Hash::make($request->password)]);
        DB::table('password_resets')->where(['email'=> $request->email])->delete();
        return response()->json([
            'response' => Response::HTTP_OK,
            'success' => true,
            'message' => 'password changed',
            'data' => [],
        ], Response::HTTP_OK);    }

    public function me()
    {
        return response()->json(auth()->user());
    }

    public function logout()
    {
        auth()->logout();

        return response()->json([
            'response' => Response::HTTP_OK,
            'success' => true,
            'message' => 'Successfully logged out',
            'data' => [],
        ], Response::HTTP_OK);    
    }

    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    protected function respondWithToken($token)
    {
        return response()->json([
            'response' => Response::HTTP_OK,
            'success' => true,
            'message' => 'Login Successfully',
            'data' => [
                'access_token' => $token,
                'token_type' => 'bearer',
                'expires_in' => auth()->factory()->getTTL() * 60
            ]

        ], Response::HTTP_OK);
    }
}
